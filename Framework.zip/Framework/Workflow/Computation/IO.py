import Workflow.Utilities.Utils

spark = Workflow.Utilities.Utils.get_sparkSession("I/O")

import logger
logger = logger.YarnLogger()


def read(path, format, delimiter, header=True):
    print("## Inside IO ##")
    # logger.info("## Inside IO ##")
    if format == "csv":
        return spark.read.format("com.databricks.spark.csv").option("header", header).option("delimiter", delimiter).load(path)
    elif format == "json":
        return spark.read.json(path)
    elif format == "parquet":
        return spark.read.parquet(path)
    else:
        return None


def write_df(path, df, format, header=True):
    print("## Inside write function ##")
    # logger.info("## Inside write function ##")
    if format == "csv":
        return df.write.mode("overwrite").format("com.databricks.spark.csv").option("header",header).save(path)
    elif format == "parquet":
        return df.write.mode("overwrite").parquet(path)
    elif format == "json":
        return df.write.mode("overwrite").json(path)
    else:
        return "format not exist"

