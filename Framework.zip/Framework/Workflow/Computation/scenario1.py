from pyspark.sql.functions import concat, col, lit, when, substring
from pyspark.sql import Window
from pyspark.sql.functions import rank, row_number

import Workflow.Utilities.UDF
import Workflow.Utilities.Utils
import pyspark.sql.functions as F

spark = Workflow.Utilities.Utils.get_sparkSession("scenario1")
import logger
logger = logger.YarnLogger()

'''
Claim SummaryDetails View DataSet
File Referred:
Proclaim: pendcl, paidcl, member, parm_id, parm_gr, parm_db
Gac: Contract, GroupOffice, Group_H_Control_Plan, Pool, Group_Version_Control, gac_h_plan_service_employee
'''


class ClaimSummaryDetails:
    def pendclaim_member_detials(self, gr, mem, pid, pdb, pcl):
        print("Count of PendClaim File:", pcl.count())
        pendclaim_mem_df = pcl.join(gr, (pcl['CL_PA_GROUP'] == gr['GR_GR_ID']) & (pcl['CL_CI_ID'] == gr['GR_CI_ID']) &
                                 (gr['GR_ID_GEN'] == '0'), how='inner')\
            .join(mem, (pcl['CL_CI_ID'] == mem['ME_CI_ID']) & (pcl['CL_PA_GROUP'] == mem['ME_GROUP']) & (pcl['CL_PA_ID'] == mem['ME_ID']), how='inner')\
            .join(pid, (pcl['CL_DIS_ID_ID_1'] == pid['ID_ID']) & (pcl['CL_CI_ID'] == pid['ID_CI_ID']), how='inner')\
            .join(pdb, (pcl['CL_CI_ID'] == pdb['DB_CI_ID']) & (pcl['CL_PA_GROUP'] == pdb['DB_GR_ID']) & (pcl['CL_PC_ID'] == pdb['DB_PRDCT']) & (pcl['CL_PI_COV'] == pdb['DB_CLSS']), how='inner')\
            .select(pcl.CL_CL_ID.alias('CL_CL_ID1'), pcl.CL_PA_ID,
                    pcl.CL_PA_GROUP,
                    pcl.CL_CL_GEN,
                    gr.GR_NAME, pcl.CL_PI_COV,
                    pcl.CL_US_ID_ASSGND,
                    pcl.CL_DIS_ID_ID_1,
                    pcl.CL_DIS_ANTCPTD_RCVRY_DATE,
                    pcl.CL_DIS_BEN_TO_DT, pcl.CL_DIS_COLA_REVIEW_DATE,
                    pcl.CL_DIS_OP_WTHD_EFFCTV_DATE,
                    pcl.CL_DIS_OP_STTS_CHNG_DATE, pcl.CL_DIS_PER_TO_DT,
                    substring(pcl.CL_US_ID_ASSGND, 1, 3).alias('IPC_CL_US_ID_ASSGND'), pcl.CL_MEMO_ID,
                    pcl.CL_MEMO_TEXT,
                    pcl.CL_B_ALLOW_1,
                    pcl.CL_CONTESTED_DAYS_ACCUM_1,
                    pcl.CL_CONTESTED_START_DT_1,
                    pcl.CL_CONTESTED_TOLL_DAYS_ACCUM_1,
                    pcl.CL_DIS_ARW_DT,
                    pcl.CL_ME_DOD,
                    pcl.CL_ME_DOR,
                    pcl.CL_DIS_OWN_JOB_PERIOD_DATE,
                    concat(pcl['CL_CLAIM_PAID_FROM_YY'], lit(''), pcl['CL_CLAIM_PAID_FROM_MM'], lit(''), pcl['CL_CLAIM_PAID_FROM_DD'])
                    .alias("CL_CLAIM_PAID_FROM_DATE"),
                    concat(pcl['CL_DIS_POL_YY'], lit(''), pcl['CL_DIS_POL_MM'], lit(''), pcl['CL_DIS_POL_DD'])
                    .alias("CL_DIS_POL_DATE"),
                    concat(pcl['CL_ACB_QUAL_DATE_YY'], lit(''), pcl['CL_ACB_QUAL_DATE_MM'], lit(''), pcl['CL_ACB_QUAL_DATE_DD'])
                    .alias("CL_ACB_QUALIFACTION_DATE"),
                    concat(pcl['CL_DIS_HSPTL_DATE_YY'], lit(''), pcl['CL_DIS_HSPTL_DATE_MM'], lit(''), pcl['CL_DIS_HSPTL_DATE_DD'])
                    .alias("CL_DIS_HSPTL_DATE"),
                    concat(pcl['CL_DIS_MRD_YY'], lit(''),
                           F.when(F.length(pcl['CL_DIS_MRD_MM']) < 2, F.lpad(pcl['CL_DIS_MRD_MM'], 2, '0'))
                           .otherwise(pcl['CL_DIS_MRD_MM']), lit(''),
                           F.when(F.length(pcl['CL_DIS_MRD_DD']) < 2, F.lpad(pcl['CL_DIS_MRD_DD'], 2, '0'))
                           .otherwise(pcl['CL_DIS_MRD_DD'])).alias("CL_DIS_MRD"),
                    pcl.CL_B_OPT1_1, pcl.CL_B_OPT2_1, pcl.CL_B_OPT3_1,
                    pcl.CL_B_OPT4_1,
                    pcl.CL_CLOSE_DATE,
                    gr.GR_CI_ID, gr.GR_GR_ID,
                    gr.GR_BCD_AVAILABLE, gr.GR_BCD_PAY_DATE, gr.GR_BCD_PAY_FREQ, gr.GR_BCD_OPT,
                    mem.ME_CI_ID, mem.ME_GROUP, mem.ME_ID, mem.ME_SEX, mem.ME_BIRTH_DT, mem.ME_NAME, mem.ME_ADDR1,
                    mem.ME_ADDR2, mem.ME_ADDR3, mem.ME_CITY, mem.ME_STATE,
                    concat(mem['ME_ZIP15'], lit('-'), mem['ME_ZIP69']).alias("ZIP"),
                    concat(mem['ME_PHONE_AREA'], lit('-'), mem['ME_PHONE_EXCHANGE'], lit('-'),
                           mem['ME_PHONE_NUMBER']).alias("ME_PHONE"),
                    mem.ME_GEN_ID.alias("ME_GEN"), mem.ME_BCD_UNIT,
                    pid.ID_CI_ID.alias("DIAG_CI_ID"), pid.ID_ID, pid.ID_DESC.alias("DIAG_ID_DESC"),
                    pdb.DB_PI_ID, pdb.DB_PRDCT, pdb.DB_CLSS, pdb.DB_GEN, pdb.DB_OPT10, pdb.DB_OPT11,
                    pdb.DB_OPT15,
                    pcl.CL_DIS_ACD_DT, pdb.DB_EFFCTV_DATE, pdb.DB_LIMIT_DATE)\
            .withColumn("DISAB_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_ACD_DT", lit("%Y%m%d")))\
            .withColumn("EFFECTIVE_DT", Workflow.Utilities.UDF.to_date_udf("DB_EFFCTV_DATE", lit("%Y%m%d")))\
            .withColumn("LIMIT_DT", Workflow.Utilities.UDF.to_date_udf("DB_LIMIT_DATE", lit("%Y%m%d"))).\
            where((col('DISAB_DT') >= col('EFFECTIVE_DT')) & (col('DISAB_DT') <= col('LIMIT_DT')))

        windowFunction = Window.partitionBy(pendclaim_mem_df["GR_CI_ID"], pendclaim_mem_df["GR_GR_ID"], pendclaim_mem_df["DB_PRDCT"], pendclaim_mem_df["DB_CLSS"]).orderBy(pendclaim_mem_df["DB_GEN"])
        rankDF = pendclaim_mem_df.withColumn("rank", rank().over(windowFunction))
        # rankDF.show(10, False)

        pend_member_df = rankDF.where(col('rank') == 1).drop("rank").drop("EFFECTIVE_DT")
        return pend_member_df

    def gac_contract_details(self, table1, table2, table3, table4, table5, table6, table7):
        pcl = table1.alias('pcl')
        con = table2.alias('con')
        pool = table3.alias('pool')
        go = table4.alias('go')
        gvc = table5.alias('gvc')
        gplan = table6.alias('gplan')
        gplan_serviceemp = table7.alias('gplanservice')

        joincondition = when((pcl['CL_PC_ID'] == 'PB') & (pcl['CL_PC_ID'] == 'SB') & (pcl['CL_PC_ID'] == 'OP') &
                             (pcl['CL_PC_ID'] == 'SO'), "LT").otherwise(pcl['CL_PC_ID']) == gplan['PRODUCT_CD']

        gac_contract_df = pcl.join(con,
                                   (pcl['CL_PI_ID'] == con['CNTRCT_ID']) &
                                   (pcl['CL_CI_ID'] == con['CO_ID']),
                                   how='left_outer')\
            .join(pool,
                  (con['POOL_CD'] == pool['POOL_CD']) &
                  (con['CO_ID'] == pool['CO_ID']),
                  how='inner')\
            .join(gvc,
                  (con['CO_ID'] == gvc['CO_ID']) &
                  (con['CNTRCT_ID'] == gvc['CONTRACT_NBR']),
                  how='inner')\
            .join(gplan,
                  (con['CNTRCT_ID'] == gplan['CONTRACT_NBR']) &
                  (con['CO_ID'] == gplan['CO_ID']) &
                  (gvc['GAC_VERSION_SEQ'] == gplan['GAC_VERSION_SEQ']) &
                  joincondition,
                  how='inner') \
            .join(gplan_serviceemp,
                  (gplan['CONTRACT_NBR'] == gplan_serviceemp['CONTRACT_NBR']) &
                  (gplan['GAC_CONTRACT_PLAN_SEQ'] == gplan_serviceemp['GAC_CONTRACT_PLAN_SEQ']),
                  how='inner') \
            .join(go,
                  (gplan_serviceemp['SERVICING_EE_GRP_OFFC_CD'] == go['GROUP_OFFC_CD']) &
                  (con['CO_ID'] == go['CO_ID']),
                  how='outer')\
            .select(pcl.CL_CI_ID, pcl.CL_CL_ID, pcl.CL_ME_LAST_GRADE_CMPLTD, pcl.CL_ME_FILING_STS,
                    pcl.CL_ME_NBR_ALLWNC, pcl.CL_STTS, pcl.CL_STTS_REASON, pcl.CL_DIS_CLAIM_TYPE,
                    pcl.CL_PI_ID, pcl.CL_DIS_REL_ID_1,
                    pcl.CL_DIS_CAUSE, pcl.CL_DIS_TYPE, pcl.CL_DIS_OCCPTNL_CODE, pcl.CL_REC_DT, pcl.CL_BASE_CLAIM,
                    pcl.CL_PC_ID, pcl.CL_ME_AU_ID, pcl.CL_ME_AU_ID_TAX, pcl.CL_GF_DV_ID, pcl.CL_SITE, pcl.CL_PA_AGE, pcl.CL_ME_WORK_LCTN,
                    pcl.CL_ME_OC_ID, pcl.CL_OC_RLTN_CODE, pcl.CL_ANYOCC_PAY_APPROVAL_FLAG, pcl.CL_ASSGND_DATE,
                    pcl.CL_DIS_DCSN_DATE, pcl.CL_DIS_BEN_FROM_DT, pcl.CL_DIS_OWN_OCC_PERIOD_DATE, pcl.CL_COMPLEXITY,
                    pcl.CL_DIS_PYMT_DAY, pcl.CL_DIS_PYMT_ADVANCE, pcl.CL_DIS_SAL_BASE, pcl.CL_DIS_SAL,
                    pcl.CL_DIS_ER_CONT_PCT, pcl.CL_DIS_OP_WTHHLDNG_AMNT, pcl.CL_DIS_OP_WTHHLDNG_OPTN1,
                    pcl.CL_DIS_OP_WTHHLDNG_OPTN2, pcl.CL_DIS_OP_WTHHLDNG_OPTN3,
                    pcl.CL_DIS_OP_WTHHLDNG_OPTN4, pcl.CL_RSRV_AMNT, pcl.CL_DIS_CLI, pcl.CL_DIS_PAYEE, pcl.CL_DIS_PR_SSN,
                    pcl.CL_DIS_PR_SUF, pcl.CL_DIS_PER_ALLOW, pcl.CL_DIS_OP_CRRNT_BLNC, pcl.CL_DIS_OP_ADJSTMNT_AMNT,
                    pcl.CL_DIS_OP_ADJSTMNT_TYPE, pcl.CL_DIS_PERIOD_COLA_FACTOR1, pcl.CL_DIS_PERIOD_COLA_FACTOR2,
                    pcl.CL_DIS_RPYMNT_AMNT, pcl.CL_DIS_RPYMNT_OPTN1, pcl.CL_DIS_MTD_ADJSTD_NET_BNFT,
                    pcl.CL_DIS_YTD_ADJSTD_NET_BNFT, pcl.CL_DIS_DTD_ADJSTD_NET_BNFT, pcl.CL_DIS_MTD_HSPTL_BNFTS,
                    pcl.CL_DIS_YTD_HSPTL_BNFTS, pcl.CL_DIS_DTD_HSPTL_BNFTS, pcl.CL_DIS_MTD_OP_WTHHLDNG,
                    pcl.CL_DIS_YTD_OP_WTHHLDNG, pcl.CL_DIS_DTD_OP_WTHHLDNG, pcl.CL_DIS_MTD_RPYMNTS,
                    pcl.CL_DIS_YTD_RPYMNTS, pcl.CL_DIS_DTD_RPYMNTS,
                    pcl.CL_DIS_MTD_OP_ADJSTMNTS, pcl.CL_DIS_YTD_OP_ADJSTMNTS, pcl.CL_DIS_DTD_OP_ADJSTMNTS,
                    pcl.CL_DIS_OP_ORGNL_BLNC_INDCTR,
                    pcl.CL_US_ID_ACCEPT, pcl.CL_GR_GROUP_OFFC, pcl.CL_RSRV_CODE, pcl.CL_RSRV_REASON,
                    pcl.CL_PYMT_MODE, pcl.CL_PEND_DAYS_ACCUM, pcl.CL_PEND_TOLL_DAYS_ACCUM, pcl.CL_PEND_TOLL_START_DT,
                    pcl.CL_CONTESTED_TOLL_START_DT, pcl.CL_BATCH_PEND_TOLL_FLAG, pcl.CL_BATCH_CONTESTED_TOLL_FLAG,
                    pcl.CL_BATCH_STTS_REASON, pcl.CL_DIS_PERIOD,
                    pcl.CL_DIS_RETRO_FLAG, pcl.CL_DIS_BASE_WAGE, pcl.CL_PI_ISSUE_STATE, pcl.CL_FORMER_CL_ID,
                    pcl.CL_GR_SRCE_OF_OLD_GR_ID, pcl.CL_GR_OLD_GR_ID, pcl.CL_DB_IPE_TYPE, pcl.CL_DB_IPE_MXMM_PRCNT,
                    pcl.CL_DB_IPE_FLAT_PRCNT, pcl.CL_DIS_DB_COLA_CUTOFF_PERIODS, pcl.CL_DIS_DB_COLA_LAG_MONTHS,
                    pcl.CL_DIS_DB_COLA_OPTN1, pcl.CL_DIS_DB_COLA_OPTN2, pcl.CL_DIS_DB_COLA_OPTN4,
                    pcl.CL_ME_YNGST_CHLD_BRTH_DATE, pcl.CL_DB_IRC_CODE, pcl.CL_DB_BEN_OPT7,
                    pcl.CL_DIS_PERIOD_MISC_ADJSTMNT, pcl.CL_DIS_PERIOD_WORK_EARNINGS, pcl.CL_ORIG_PERIOD_FROM_DATE,
                    pcl.CL_ORIG_PERIOD_TO_DATE, pcl.CL_DIS_DB_PYMT_OPT3, pcl.CL_DIS_DB_COLA_PCT,
                    pcl.CL_DIS_DB_COLA_MXMM_PRCNT,
                    pcl.CL_DIS_MA_RA_PCT, pcl.CL_DIS_MA_GRA_PCT, pcl.CL_DIS_MA_SRA_PCT, pcl.CL_DIS_MA_GSRA_PCT,
                    pcl.CL_DIS_MA_PA_PCT, pcl.CL_DIS_PER_WM_AMNT,
                    pcl.CL_DIS_DB_BEN_OPT3, pcl.CL_DB_OFFSTS_6, pcl.CL_DIS_DB_OPT2, pcl.CL_DIS_MIN_PYMT_AMT,
                    pcl.CL_DIS_ALL_SRCS_LIMIT,
                    pcl.CL_OR_CODE, pcl.CL_DIS_OR_PLAN_IND, pcl.CL_DIS_OR_COV_IND, pcl.CL_DIS_OR_HIST_IND,
                    pcl.CL_DB_SVCS_ADMIN_FLAG, pcl.CL_DIS_REHAB_RTW_DT,
                    pcl.CL_DIS_RTW_DT, pcl.CL_RTN_TO_WRK_STATUS_CD, pcl.CL_AUTO_PEND_EVENTS_FLAG,
                    pcl.CL_US_ASSGND_EU_ID, pcl.CL_DIS_STOP_DT, pcl.CL_DB_ACB_CATCHUP_OPTION,
                    pcl.CL_DB_ACB_QUALIFICATION_MONTHS, pcl.CL_ABSENCE_ID, pcl.CL_CN_RDRA_DAYS_IN_YEAR,
                    pcl.CL_DIS_DB_PYMT_OPT4, pcl.CL_DIS_DB_PYMT_OPT5, pcl.CL_DB_SICKPAY_DAILY_RATE,
                    pcl.CL_CN_CALENDAR_ID, pcl.CL_DIS_MTD_SCKLV_BNFT, pcl.CL_DIS_YTD_SCKLV_BNFT,
                    pcl.CL_DIS_DTD_SCKLV_BNFT, pcl.CL_DIS_RLTD_CL_ID,
                    pcl.CL_DIS_OP_TRNSFR_CL_ID, pcl.CL_DIS_SDR, pcl.CL_AVG_MNTHLY_SAL,
                    pcl.CL_DB_SDI_FLAG, pcl.CL_DB_STATE_PLUS, pcl.CL_DIS_DB_OPT14, pcl.CL_DB_SDI_STATE,
                    pcl.CL_DB_OFFSTS_7,
                    pcl.CL_DIS_PERIOD_ADJSTD_NET_BNFT, pcl.CL_C_CHK_AMT, pcl.CL_DIS_PERIOD_BNFTS_TRSFRRD,
                    pcl.CL_DIS_PERIOD_OP_WTHHLDNG, pcl.CL_LAST_UPD_DT, pcl.CL_DB_OFFSTS_2, pcl.CL_DB_OPT16,
                    pcl.CL_DIS_LDW_DT, pcl.CL_DIS_LSB_FLAG,
                    gvc.GAC_VERSION_SEQ, go.GROUP_OFFC_CD.alias('GO_GROUP_OFFC'),
                    go.GROUP_OFFC_NM.alias('GO_GROUP_OFFC_NM'), go.REGION_NBR.alias('GO_REGION_NBR'), go.OLD_GROUP_OFFC_NBR.alias('GO_OLD_GROUP_OFFC_NBR'),
                    gplan.GAC_CONTRACT_PLAN_SEQ, gplan.PRODUCT_CD.alias('GCP_PRODUCT_CD'), gplan.POLICY_PLAN_ID.alias('GCP_POLICY_PLAN_ID'), gplan.GAC_VERSION_SEQ.alias('GCP_GAC_VERSION_SEQ'),
                    pool.POOL_CD.alias('POOL_CD'), pool.DESCP.alias('POOL_DESC'), pool.BUS_SEGMENT_CD.alias('POOL_BUS_SEGMNENT'),
                    gvc.VERSION_FROM_DT, gvc.VERSION_TO_DT, gplan.EFFECTIVE_DT, pcl.CL_INPUT_DT,
                    gplan_serviceemp.VERSION_FROM_DT.alias('SER_EMP_VERSION_FROM_DT'),
                    gplan_serviceemp.VERSION_TO_DT.alias('SER_EMP_VERSION_TO_DT'))\
            .withColumn("FROM_DATE", Workflow.Utilities.UDF.to_date_udf1("VERSION_FROM_DT", lit("%Y%m%d")))\
            .withColumn("TO_DATE", Workflow.Utilities.UDF.to_date_udf1("VERSION_TO_DT", lit("%Y%m%d")))\
            .withColumn("CL_INPUT_DT", Workflow.Utilities.UDF.to_date_udf("CL_INPUT_DT", lit("%Y%m%d")))\
            .withColumn("SER_EMP_VERSION_FROM_DT", Workflow.Utilities.UDF.to_date_udf1("SER_EMP_VERSION_FROM_DT", lit("%Y%m%d")))\
            .withColumn("SER_EMP_VERSION_TO_DT", Workflow.Utilities.UDF.to_date_udf1("SER_EMP_VERSION_TO_DT", lit("%Y%m%d")))\
            .where((col('CL_INPUT_DT') >= col('FROM_DATE'))
                   & (col('CL_INPUT_DT') <= col('TO_DATE'))
                   & (col('CL_INPUT_DT') >= col('SER_EMP_VERSION_FROM_DT'))
                   & (col('CL_INPUT_DT') <= col('SER_EMP_VERSION_TO_DT')))

        print("#####Join Finished........Window Function Started####")
        # logger.info("#####Join Finished........Window Function Started####")
        window = Window.partitionBy(pcl['CL_CL_ID']).orderBy(gplan['EFFECTIVE_DT'].desc())

        print("### Windowing Function is Completed.........")
        # logger.info("### Windowing Function is Completed.........")
        rankDF = gac_contract_df.withColumn("EFFECTIVE_DT_RANK", row_number().over(window))
        # rankDF.show(10, False)

        print("####Dropping Rank Column..........")
        # logger.info("####Dropping Rank Column..........")
        contract_df = rankDF.where(col('EFFECTIVE_DT_RANK') == 1).drop("EFFECTIVE_DT_RANK")
        print("######Join is Finished..........")
        # logger.info("######Join is Finished..........")
        return contract_df

    def member_contract_detials_view(self, gac_data, pend_member_data):
        contract_member_df = pend_member_data.join(gac_data, (pend_member_data['CL_CL_ID1'] == gac_data['CL_CL_ID']),
                                                   how='left_outer')
        return contract_member_df

    def claimsummary(self, pendclaimsummary, deductions):
        pendclaimsummary.alias('pcl')
        deductions.alias('ded')

        pendclaimsummary.rdd.persist()
        deductions.rdd.persist()

        claimsummary_df = pendclaimsummary.join(deductions, (pendclaimsummary['CL_CL_GEN'] == deductions['AD_CL_GEN']) &
                                                (pendclaimsummary['CL_CL_ID'] == deductions['AD_CL_ID']),
                                                how='left_outer')

        pendclaimsummary.rdd.unpersist()
        deductions.rdd.unpersist()
        print("####Final Output..........!!!")
        claimsummary_df.rdd.persist()
        print("Count of Final DataSet:", claimsummary_df.count())
        # claimsummary_df.show(20, False)
        return claimsummary_df


