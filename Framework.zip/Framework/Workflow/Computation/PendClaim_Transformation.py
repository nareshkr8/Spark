from pyspark.sql.functions import col, lit, when
import Workflow.Utilities.UDF
import Workflow.Utilities.Utils

spark = Workflow.Utilities.Utils.get_sparkSession("Rules Engine")


class PendClaimSummary:
    def transformation_df(self, member_data):
        df = member_data.alias("df")
        transformation_df = member_data.select(df.CL_ME_LAST_GRADE_CMPLTD, df.ME_SEX, df.ME_NAME, df.ME_ADDR1,
                                               df.ME_ADDR2, df.ME_ADDR3, df.ME_CITY, df.ME_STATE, df.ZIP,
                                               df.ME_PHONE, df.ME_GEN, df.CL_ME_FILING_STS, df.CL_ME_NBR_ALLWNC,
                                               df.CL_CI_ID, df.GR_NAME, df.CL_PA_GROUP, df.CL_CL_ID, df.CL_STTS,
                                               df.CL_STTS_REASON, df.CL_DIS_CLAIM_TYPE, df.CL_PI_ID, df.CL_PI_COV,
                                               df.CL_US_ID_ASSGND, df.CL_DIS_CAUSE, df.CL_DIS_TYPE,
                                               df.CL_DIS_OCCPTNL_CODE, df.CL_BASE_CLAIM, df.CL_PC_ID,
                                               df.CL_ME_AU_ID, df.CL_ME_AU_ID_TAX, df.CL_GF_DV_ID,
                                               df.CL_SITE, df.CL_PA_AGE, df.CL_ME_WORK_LCTN, df.CL_ME_OC_ID,
                                               df.CL_OC_RLTN_CODE, df.CL_ANYOCC_PAY_APPROVAL_FLAG,
                                               df.CL_DIS_ID_ID_1, df.CL_DIS_REL_ID_1, df.CL_COMPLEXITY,
                                               df.CL_DIS_PYMT_DAY, df.CL_DIS_PYMT_ADVANCE, df.CL_DIS_SAL_BASE,
                                               df.CL_DIS_SAL, df.CL_DIS_ER_CONT_PCT, df.CL_DIS_OP_WTHHLDNG_AMNT,
                                               df.CL_DIS_OP_WTHHLDNG_OPTN1, df.CL_DIS_OP_WTHHLDNG_OPTN2,
                                               df.CL_DIS_OP_WTHHLDNG_OPTN3, df.CL_DIS_OP_WTHHLDNG_OPTN4,
                                               df.CL_RSRV_AMNT, df.CL_DIS_CLI, df.CL_DIS_PAYEE, df.CL_DIS_PR_SUF,
                                               df.GR_BCD_AVAILABLE, df.CL_DIS_PER_ALLOW, df.CL_DIS_OP_CRRNT_BLNC,
                                               df.CL_DIS_OP_ADJSTMNT_AMNT, df.CL_DIS_OP_ADJSTMNT_TYPE,
                                               df.CL_DIS_PERIOD_COLA_FACTOR1, df.CL_DIS_PERIOD_COLA_FACTOR2,
                                               df.CL_DIS_RPYMNT_AMNT, df.CL_DIS_RPYMNT_OPTN1,
                                               df.CL_DIS_MTD_ADJSTD_NET_BNFT, df.CL_DIS_YTD_ADJSTD_NET_BNFT,
                                               df.CL_DIS_DTD_ADJSTD_NET_BNFT, df.CL_DIS_MTD_HSPTL_BNFTS,
                                               df.CL_DIS_YTD_HSPTL_BNFTS, df.CL_DIS_DTD_HSPTL_BNFTS,
                                               df.CL_DIS_MTD_OP_WTHHLDNG, df.CL_DIS_YTD_OP_WTHHLDNG,
                                               df.CL_DIS_DTD_OP_WTHHLDNG, df.CL_DIS_MTD_RPYMNTS,
                                               df.CL_DIS_YTD_RPYMNTS, df.CL_DIS_DTD_RPYMNTS,
                                               df.CL_DIS_MTD_OP_ADJSTMNTS, df.CL_DIS_YTD_OP_ADJSTMNTS,
                                               df.CL_DIS_DTD_OP_ADJSTMNTS, df.CL_DIS_OP_ORGNL_BLNC_INDCTR,
                                               df.CL_US_ID_ACCEPT, df.CL_INPUT_DT, df.CL_GR_GROUP_OFFC,
                                               df.CL_RSRV_CODE, df.CL_RSRV_REASON, df.IPC_CL_US_ID_ASSGND,
                                               df.CL_DIS_LSB_FLAG, df.CL_DIS_DB_OPT14, df.CL_PYMT_MODE,
                                               df.CL_MEMO_ID, df.CL_MEMO_TEXT, df.CL_PEND_DAYS_ACCUM,
                                               df.CL_PEND_TOLL_DAYS_ACCUM, df.CL_CONTESTED_DAYS_ACCUM_1,
                                               df.CL_CONTESTED_TOLL_DAYS_ACCUM_1, df.CL_BATCH_PEND_TOLL_FLAG,
                                               df.CL_BATCH_CONTESTED_TOLL_FLAG, df.CL_BATCH_STTS_REASON,
                                               df.CL_DIS_PERIOD, df.CL_B_ALLOW_1, df.CL_DIS_RETRO_FLAG,
                                               df.CL_PI_ISSUE_STATE, df.CL_FORMER_CL_ID,
                                               df.CL_GR_SRCE_OF_OLD_GR_ID, df.CL_GR_OLD_GR_ID,
                                               df.CL_DB_IPE_TYPE, df.CL_DB_IPE_MXMM_PRCNT, df.CL_DB_IPE_FLAT_PRCNT,
                                               df.CL_DIS_DB_COLA_CUTOFF_PERIODS, df.CL_DIS_DB_COLA_LAG_MONTHS,
                                               df.CL_DIS_DB_COLA_OPTN1, df.CL_DIS_DB_COLA_OPTN2,
                                               df.CL_DIS_DB_COLA_OPTN4, df.CL_DB_IRC_CODE, df.CL_DB_BEN_OPT7,
                                               df.CL_DIS_PERIOD_MISC_ADJSTMNT, df.CL_DIS_PERIOD_WORK_EARNINGS,
                                               df.CL_DIS_DB_PYMT_OPT3, df.CL_DIS_DB_COLA_PCT, df.CL_DIS_DB_COLA_MXMM_PRCNT,
                                               df.CL_DIS_MA_RA_PCT, df.CL_DIS_MA_GRA_PCT, df.CL_DIS_MA_SRA_PCT,
                                               df.CL_DIS_MA_GSRA_PCT, df.CL_DIS_MA_PA_PCT, df.CL_DIS_PER_WM_AMNT,
                                               df.CL_DIS_DB_BEN_OPT3, df.CL_DB_OFFSTS_6, df.CL_DIS_DB_OPT2,
                                               df.CL_DIS_MIN_PYMT_AMT, df.CL_DIS_ALL_SRCS_LIMIT, df.CL_OR_CODE,
                                               df.CL_DIS_OR_PLAN_IND, df.CL_DIS_OR_COV_IND, df.CL_DIS_OR_HIST_IND,
                                               df.CL_DB_SVCS_ADMIN_FLAG, df.CL_RTN_TO_WRK_STATUS_CD,
                                               df.CL_AUTO_PEND_EVENTS_FLAG, df.CL_US_ASSGND_EU_ID,
                                               df.CL_DB_ACB_CATCHUP_OPTION, df.CL_DB_ACB_QUALIFICATION_MONTHS,
                                               df.CL_ABSENCE_ID, df.CL_CN_RDRA_DAYS_IN_YEAR, df.CL_DIS_DB_PYMT_OPT4,
                                               df.CL_DIS_DB_PYMT_OPT5, df.CL_DB_SICKPAY_DAILY_RATE,
                                               df.CL_CN_CALENDAR_ID, df.CL_DIS_MTD_SCKLV_BNFT,
                                               df.CL_DIS_YTD_SCKLV_BNFT, df.CL_DIS_DTD_SCKLV_BNFT,
                                               df.CL_DIS_RLTD_CL_ID, df.CL_DIS_OP_TRNSFR_CL_ID,
                                               df.CL_DIS_SDR, df.CL_AVG_MNTHLY_SAL,
                                               df.CL_DB_SDI_FLAG, df.CL_DB_STATE_PLUS,
                                               df.CL_DB_SDI_STATE, df.CL_DB_OFFSTS_7,
                                               df.CL_DIS_PERIOD_ADJSTD_NET_BNFT, df.CL_C_CHK_AMT,
                                               df.CL_DIS_PERIOD_BNFTS_TRSFRRD, df.CL_DIS_PERIOD_OP_WTHHLDNG,
                                               df.CL_B_OPT1_1, df.CL_B_OPT2_1, df.CL_B_OPT3_1, df.CL_B_OPT4_1,
                                               df.ME_BCD_UNIT, df.GR_BCD_PAY_DATE, df.GR_BCD_PAY_FREQ,
                                               df.GR_BCD_OPT, df.CL_DB_OFFSTS_2, df.CL_DB_OPT16,
                                               df.CL_PA_ID, df.ME_BIRTH_DT, df.CL_REC_DT,
                                               df.CL_LAST_UPD_DT,
                                               df.CL_ASSGND_DATE, df.CL_DIS_DCSN_DATE, df.CL_DIS_ACD_DT,
                                               df.CL_DIS_BEN_TO_DT, df.CL_DIS_ANTCPTD_RCVRY_DATE,
                                               df.CL_CLOSE_DATE, df.CL_DIS_BEN_FROM_DT,
                                               df.CL_DIS_COLA_REVIEW_DATE,
                                               df.CL_DIS_OWN_OCC_PERIOD_DATE, df.CL_DIS_OP_WTHD_EFFCTV_DATE,
                                               df.CL_DIS_PR_SSN, df.CL_DIS_OP_STTS_CHNG_DATE,
                                               df.CL_DIS_PER_TO_DT, df.CL_DIS_POL_DATE,
                                               df.CL_PEND_TOLL_START_DT, df.CL_CONTESTED_TOLL_START_DT,
                                               df.CL_CONTESTED_START_DT_1, df.CL_DIS_BASE_WAGE,
                                               df.CL_CLAIM_PAID_FROM_DATE, df.CL_ME_YNGST_CHLD_BRTH_DATE,
                                               df.CL_ORIG_PERIOD_FROM_DATE, df.CL_ORIG_PERIOD_TO_DATE,
                                               df.CL_DIS_REHAB_RTW_DT, df.CL_DIS_RTW_DT,
                                               df.CL_DIS_ARW_DT, df.CL_DIS_STOP_DT, df.CL_ME_DOD,
                                               df.CL_ME_DOR, df.CL_ACB_QUALIFACTION_DATE,
                                               df.CL_DIS_HSPTL_DATE,
                                               df.CL_DIS_OWN_JOB_PERIOD_DATE, df.CL_DIS_LDW_DT, df.CL_DIS_MRD,
                                               df.CL_CL_GEN
                                                     )\
            .withColumn("ME_BIRTH_DT", Workflow.Utilities.UDF.to_date_udf("ME_BIRTH_DT", lit("%Y%m%d")))\
            .withColumn("CL_REC_DT", Workflow.Utilities.UDF.to_date_udf("CL_REC_DT", lit("%Y%m%d")))\
            .withColumn("CL_LAST_UPD_DT", Workflow.Utilities.UDF.to_date_udf("CL_LAST_UPD_DT", lit("%Y%m%d")))\
            .withColumn("CL_OC_RLTN_CODE", when(col("CL_OC_RLTN_CODE") == 0, "Officials and Managers")
                        .when(col("CL_OC_RLTN_CODE") == 1, "Office and Clerical")
                        .when(col("CL_OC_RLTN_CODE") == 2, "Professional")
                        .when(col("CL_OC_RLTN_CODE") == 3, "Technicians")
                        .when(col("CL_OC_RLTN_CODE") == 4, "Sales")
                        .when(col("CL_OC_RLTN_CODE") == 5, "Crafts(Skilled)")
                        .when(col("CL_OC_RLTN_CODE") == 6, "Operatives(Semi-Skilled")
                        .when(col("CL_OC_RLTN_CODE") == 7, "Laborers")
                        .when(col("CL_OC_RLTN_CODE") == 8, "Service Worker")
                        .when(col("CL_OC_RLTN_CODE") == 9, "Safety")
                        .otherwise("Unknown"))\
            .withColumn("CL_DIS_REL_ID_1", when(col("CL_DIS_REL_ID_1") == 20, "Mental Disorders")
                        .when(col("CL_DIS_REL_ID_1") == 21, "Cancer")
                        .when(col("CL_DIS_REL_ID_1") == 22, "Nervous System")
                        .when(col("CL_DIS_REL_ID_1") == 23, "CirculatoryHeart")
                        .when(col("CL_DIS_REL_ID_1") == 24, "Respiratory")
                        .when(col("CL_DIS_REL_ID_1") == 25, "Digestive")
                        .when(col("CL_DIS_REL_ID_1") == 26, "Reproductive/Urinary")
                        .when(col("CL_DIS_REL_ID_1") == 27, "Back Conditions")
                        .when(col("CL_DIS_REL_ID_1") == 28, "Eye,Ear,Nose and Throat")
                        .when(col("CL_DIS_REL_ID_1") == 29, "Misc/Unclassified")
                        .when(col("CL_DIS_REL_ID_1") == 30, "Maternity")
                        .when(col("CL_DIS_REL_ID_1") == 31, "Aids")
                        .when(col("CL_DIS_REL_ID_1") == 32, "Fracture")
                        .when(col("CL_DIS_REL_ID_1") == 33, "Multiple Sclerosis")
                        .when(col("CL_DIS_REL_ID_1") == 34, "Diabetes Mellitus")
                        .when(col("CL_DIS_REL_ID_1") == 35, "Lupus Erythematosis")
                        .when(col("CL_DIS_REL_ID_1") == 36, "Chronic Fatigue/EBV")
                        .when(col("CL_DIS_REL_ID_1") == 37, "Drug/Alcohol Abuse")
                        .when(col("CL_DIS_REL_ID_1") == 38, "Bone,Joint,Muscle other than back"))\
            .withColumn("CL_ASSGND_DATE", Workflow.Utilities.UDF.to_date_udf("CL_ASSGND_DATE", lit("%Y%m%d")))\
            .withColumn("RECOV_DT", when(col("CL_DIS_ANTCPTD_RCVRY_DATE") > col("CL_DIS_BEN_TO_DT")+1, lit("CL_DIS_BEN_TO_DT")))\
            .withColumn("CL_DIS_PR_SSN", when(col("CL_DIS_PR_SSN") == '%        ', col("CL_DIS_PR_SSN")))\
            .withColumn("CL_DIS_DCSN_DATE",  Workflow.Utilities.UDF.to_date_udf("CL_DIS_DCSN_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_ACD_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_ACD_DT", lit("%Y%m%d")))\
            .withColumn("CL_DIS_BEN_TO_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_BEN_TO_DT", lit("%Y%m%d")))\
            .withColumn("CL_DIS_ANTCPTD_RCVRY_DATE", Workflow.Utilities.UDF.to_date_udf("CL_DIS_ANTCPTD_RCVRY_DATE", lit("%Y%m%d")))\
            .withColumn("CL_CLOSE_DATE", Workflow.Utilities.UDF.to_date_udf("CL_CLOSE_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_BEN_FROM_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_BEN_FROM_DT", lit("%Y%m%d")))\
            .withColumn("CL_DIS_COLA_REVIEW_DATE", Workflow.Utilities.UDF.to_date_udf("CL_DIS_COLA_REVIEW_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_OWN_OCC_PERIOD_DATE", Workflow.Utilities.UDF.to_date_udf("CL_DIS_OWN_OCC_PERIOD_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_OP_WTHD_EFFCTV_DATE", Workflow.Utilities.UDF.to_date_udf("CL_DIS_OP_WTHD_EFFCTV_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_OP_STTS_CHNG_DATE", Workflow.Utilities.UDF.to_date_udf("CL_DIS_OP_STTS_CHNG_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_PER_TO_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_PER_TO_DT", lit("%Y%m%d")))\
            .withColumn("CL_DIS_POL_DATE", Workflow.Utilities.UDF.to_date_udf("CL_DIS_POL_DATE", lit("%Y%m%d")))\
            .withColumn("CL_PEND_TOLL_START_DT", Workflow.Utilities.UDF.to_date_udf("CL_PEND_TOLL_START_DT", lit("%Y%m%d")))\
            .withColumn("CL_CONTESTED_TOLL_START_DT", Workflow.Utilities.UDF.to_date_udf("CL_CONTESTED_TOLL_START_DT", lit("%Y%m%d")))\
            .withColumn("CL_CONTESTED_START_DT_1", Workflow.Utilities.UDF.to_date_udf("CL_CONTESTED_START_DT_1", lit("%Y%m%d")))\
            .withColumn("CL_CLAIM_PAID_FROM_DATE", Workflow.Utilities.UDF.to_date_udf("CL_CLAIM_PAID_FROM_DATE", lit("%Y%m%d")))\
            .withColumn("CL_ME_YNGST_CHLD_BRTH_DATE", Workflow.Utilities.UDF.to_date_udf("CL_ME_YNGST_CHLD_BRTH_DATE", lit("%Y%m%d")))\
            .withColumn("CL_ORIG_PERIOD_FROM_DATE", Workflow.Utilities.UDF.to_date_udf("CL_ORIG_PERIOD_FROM_DATE", lit("%Y%m%d")))\
            .withColumn("CL_ORIG_PERIOD_TO_DATE", Workflow.Utilities.UDF.to_date_udf("CL_ORIG_PERIOD_TO_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_REHAB_RTW_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_REHAB_RTW_DT", lit("%Y%m%d")))\
            .withColumn("CL_DIS_RTW_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_RTW_DT", lit("%Y%m%d")))\
            .withColumn("CL_DIS_ARW_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_ARW_DT", lit("%Y%m%d")))\
            .withColumn("CL_DIS_STOP_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_STOP_DT", lit("%Y%m%d")))\
            .withColumn("CL_ME_DOD", Workflow.Utilities.UDF.to_date_udf("CL_ME_DOD", lit("%Y%m%d")))\
            .withColumn("CL_ME_DOR", Workflow.Utilities.UDF.to_date_udf("CL_ME_DOR", lit("%Y%m%d")))\
            .withColumn("CL_ACB_QUALIFACTION_DATE", Workflow.Utilities.UDF.to_date_udf("CL_ACB_QUALIFACTION_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_HSPTL_DATE", Workflow.Utilities.UDF.to_date_udf("CL_ACB_QUALIFACTION_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_OWN_JOB_PERIOD_DATE", Workflow.Utilities.UDF.to_date_udf("CL_DIS_OWN_JOB_PERIOD_DATE", lit("%Y%m%d")))\
            .withColumn("CL_DIS_LDW_DT", Workflow.Utilities.UDF.to_date_udf("CL_DIS_LDW_DT", lit("%Y%m%d")))\
            .withColumn("CL_DIS_MRD", Workflow.Utilities.UDF.to_date_udf("CL_DIS_MRD", lit("%Y%m%d")))
        return transformation_df
