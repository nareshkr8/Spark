# from pyspark.sql import SparkSession
# import pandas as pd
#
# spark = SparkSession \
#         .builder \
#         .appName("read_file") \
#         .enableHiveSupport() \
#         .getOrCreate()
#
# df = spark.createDataFrame([("foo", 1), ("bar", 2), ("baz", 3)])
# df.show(False)
#
#         # rdd = spark.sparkContext.parallelize(
#         #     [(0, 1), (0, 1), (0, 2), (1, 2), (1, 10), (1, 20), (3, 18), (3, 18), (3, 18)])
#         # df = pd.DataFrame(rdd, columns=['id', 'score'])
#         # df.createOrReplaceTempView("df")
#         # test_df = spark.sql("SELECT * from df")
#         # test_df.show(False)
#
#         # path = "C:/Users/s005778/Desktop/test.csv"
#         # outputpath = "C:/Desktop/testlog/"
#         # df = read(path, "csv", True)
#         # # df1 = spark.read.format("com.databricks.spark.csv").option("header", "true").load(path)
#         # df.show()
#         # # df1 = df.withColumn("parsed_date", to_date_udf("date", lit('%d-%b-%y'))).show()
#         # df1 = df.withColumn("parsed_date", to_date_udf("date", lit('%d-%b-%y')))
#         #
#         #
#         # # df1.write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(outputpath)
#         # """writing the file to parquet."""
#         # write_df(outputpath, df1, "json", True)
#
#
#
