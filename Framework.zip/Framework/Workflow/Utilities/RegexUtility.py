from azure.datalake.store import core, lib
import re

tenant = '9efd56dd-e9db-43bf-8447-60d4413b594a'
client_id = '20ef0a7b-cbe0-44f5-a15c-c68f2ebf7908'
client_secret = 'f0UE7YRYVENXzZVKh+Tm3pUOUcv7FA96muvBAzpEu6w='
RESOURCE = 'edpdlkstrgd001'

token = lib.auth(tenant_id=tenant,
                 client_secret=client_secret,
                 client_id=client_id)

adlsFileSystemClient = core.AzureDLFileSystem(token, store_name=RESOURCE)


class Regex:
    def regex_utility(self, dir):
        file_list = []
        p = re.compile(r'([\w+]\_[\d+]_[\d+]_)')
        for file_list in adlsFileSystemClient.listdir('/raw/mf-proclm-claims/daily/' + dir):
            d = p.search(file_list)
            if (d != None):
                print(file_list)
        return d


