import datetime
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
import Workflow.Utilities.Utils
from pyspark.sql.functions import lit

spark = Workflow.Utilities.Utils.get_sparkSession("UDF")


def date_validate(date_str, format):
    if date_str is None:
        return None
    elif date_str == "0" or date_str == "000" or date_str == "00000000":
        return "00000000"
    else:
        if len(date_str) < 8:
            date_str1 = str(int(date_str) + 20000000)
            if int(date_str1[0:4]) > 2050:
                return 19000000 + int(date_str)
            else:
                return 20000000 + int(date_str)
    try:
        dt = datetime.datetime.strptime(date_str, format)
    except:
        return "99991231"
    return dt.date().strftime('%Y%m%d')


to_date_udf = udf(date_validate, StringType())


def date_validate1(date_str, format):
    if date_str is None:
        return None
    elif date_str == "0" or date_str == "000" or date_str == "00000000":
        return "00000000"
    else:
        if len(date_str) > 8:
            date_format = date_str[0:4] + date_str[5:7] + date_str[8:10]
            return date_format
    try:
        dt = datetime.datetime.strptime(date_str, format)
    except:
        return "99991231"
    return dt.date().strftime('%Y%m%d')


to_date_udf1 = udf(date_validate1, StringType())

''''
def is_digit(value, String):
    if value:
        return value.isdigit()
    else:
        return "000000000"


is_digit_udf = udf(is_digit, StringType)

'''''

# getConcatenated = udf((first: String, second: String))
#
# //use withColumn method to add a new column called newColName
# df.withColumn("newColName", getConcatenated($"col1", $"col2")).select("newColName", "col1", "col2").show()
