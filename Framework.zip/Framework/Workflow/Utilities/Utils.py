from os.path import abspath

from pyspark.sql import SparkSession

# warehouse_location = abspath('spark-warehouse')


def get_sparkSession(app_name):
    spark = SparkSession \
        .builder \
        .appName(app_name) \
        .enableHiveSupport() \
        .getOrCreate()
    return spark
