import Workflow.Computation.IO
import Workflow.Utilities.Utils


spark = Workflow.Utilities.Utils.get_sparkSession("InputSources")
import logger
logger = logger.YarnLogger()


class Input:
    '''
    parameterized the function from main class & add the logging functionality --
    '''
    def read_file(self, path, format, header=True):
        try:
            tablename = path.split(' ')[-1].split('/')[-1]
            print("Reading the file: " +tablename)
            # logger.info("Reading the file: " +tablename)
            df = Workflow.Computation.IO.read(path, format, header)
            df.show(5, False)
            return df
        except:
            print("File Not Found.......:" +tablename)
            # logger.info("File Not Found.......:" +tablename)
            return FileNotFoundError
    # def parm_gr(self):
    #     print("###Reading parm_gr###")
    #     try:
    #         parm_gr_df = IO.read("C:/Users/s005778/Downloads/parm_gr.csv", "csv", True)
    #         parm_gr_df.show(5, False)
    #         return parm_gr_df
    #     except:
    #         print("File Not Found......")
    #         return FileNotFoundError
    #
    # def member(self):
    #     print("###Reading member###")
    #     try:
    #         member_df = IO.read("C:/Users/s005778/Downloads/member.csv", "csv", True)
    #         member_df.show(5, False)
    #         return member_df
    #     except:
    #         print("File Not Found......")
    #         return FileNotFoundError
    #
    # def parm_id(self):
    #     print("###Reading parm_id###")
    #     try:
    #         parm_id_df = IO.read("C:/Users/s005778/Downloads/parm_id.csv", "csv", True)
    #         parm_id_df.show(5, False)
    #         return parm_id_df
    #     except:
    #         print("File Not Found......")
    #         return FileNotFoundError
    #
    # def parm_db(self):
    #     print("###Reading parm_db###")
    #     try:
    #         parm_db_df = IO.read("C:/Users/s005778/Downloads/parm_db.csv", "csv", True)
    #         parm_db_df.show(5, False)
    #         return parm_db_df
    #     except:
    #         print("File Not Found......")
    #         return FileNotFoundError
