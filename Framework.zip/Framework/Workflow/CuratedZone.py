import datetime
import os
import sys
from pyspark.sql import DataFrame, SparkSession
import yaml
import urllib


# spark = Workflow.Utilities.Utils.get_sparkSession("read_file")


spark = SparkSession \
    .builder \
    .appName("PendClaimSummaryViewDetails") \
    .enableHiveSupport() \
    .config("spark.sql.broadcastTimeout", "36000") \
    .getOrCreate()

parms = sys.argv[1].split(",")
# spark = Workflow.Utilities.Utils.get_sparkSession("read_file")


framework_zip_file = parms[0]
logger_file = parms[1]
spark.sparkContext.addPyFile(framework_zip_file)#'adl://edpdlkstrgd001.azuredatalakestore.net/raw/Framework.zip'
spark.sparkContext.addPyFile(logger_file)#'adl://edpdlkstrgd001.azuredatalakestore.net/raw/logger.py'
import logger
logger = logger.YarnLogger()
import Workflow.Sources.InputSources
import Workflow.Computation.scenario1
import Workflow.Utilities.Utils
from Workflow.Computation.IO import write_df
import Workflow.Computation.PendClaim_Transformation
# log4jLogger = spark._jvm.org.apache.log4j
# log = log4jLogger.LogManager.getLogger(__name__)
# log.warn("Hello World!")

date = datetime.date.today().strftime("%Y%m%d")
print("Current Date:" + date)


class SparkEtl(object):
    def __init__(self,sparkSession, db_config = None):
        self.sparkSession = sparkSession
        self.db_config = db_config


if __name__ == '__main__':
    print("Job Started at : " + str(datetime.datetime.now()))
    logger.info("Job Started at : " + str(datetime.datetime.now()))

    yaml_file = parms[5]#'https://edpstracctd001.blob.core.windows.net/scripts/curatedtesting/properties.yaml?st=2019-08-21T19%3A41%3A37Z&se=2019-12-22T19%3A41%3A00Z&sp=rl&sv=2018-03-28&sr=b&sig=tnPH%2BigY9L2C5HC9eSFInSyxtIFStzqAFThCrFYoRRg%3D'
    response = urllib.urlopen(yaml_file)

    config_dict = yaml.load(response)

    raw_base_proclaim_folder = config_dict['common']['adls_raw_base_path']
    curated_base_folder = config_dict['common']['adls_curated_base_path']
    raw_base_gac_folder = config_dict['common']['adls_raw_base_gac_path']

    print("###Reading ProClaim Tables...###")
    pendclaim_df = raw_base_proclaim_folder + '/' + config_dict['files']['proclaim']['pendclaim']
    parm_gr_df = raw_base_proclaim_folder + '/' + config_dict['files']['proclaim']['parm_gr']
    member_df = raw_base_proclaim_folder + '/' + config_dict['files']['proclaim']['member']
    parm_id_df = raw_base_proclaim_folder + '/' + config_dict['files']['proclaim']['parm_id']
    parm_db_df = raw_base_proclaim_folder + '/' + config_dict['files']['proclaim']['parm_db']

    inputobj = Workflow.Sources.InputSources.Input()
    gr = inputobj.read_file(parm_gr_df, "csv", "|")
    mem = inputobj.read_file(member_df, "csv", "|")
    pid = inputobj.read_file(parm_id_df, "csv", "|")
    pdb = inputobj.read_file(parm_db_df, "csv", "|")
    pcl = inputobj.read_file(pendclaim_df, "csv", "|")
    csd = Workflow.Computation.scenario1.ClaimSummaryDetails()
    pend_member_data = csd.pendclaim_member_detials(gr, mem, pid, pdb, pcl)

    print("###Reading GAC Tables...###")
    contract_df = raw_base_gac_folder + '/' + config_dict['files']['gac']['contract']
    pool_df = raw_base_gac_folder + '/' + config_dict['files']['gac']['pool']
    group_offc_df = raw_base_gac_folder + '/' + config_dict['files']['gac']['group_office']
    group_version_control_df = raw_base_gac_folder + '/' + config_dict['files']['gac']['gac_version_control']
    gac_h_control_plan_df = raw_base_gac_folder + '/' + config_dict['files']['gac']['gac_h_control_plan']
    gac_h_plan_service_employee = raw_base_gac_folder + '/' + config_dict['files']['gac']['gac_h_plan_service_employee']

    gac_table1 = inputobj.read_file(pendclaim_df, "csv", "|")
    gac_table2 = inputobj.read_file(contract_df, "csv", "|")
    gac_table3 = inputobj.read_file(pool_df, "csv", "|")
    gac_table4 = inputobj.read_file(group_offc_df, "csv", "|")
    gac_table5 = inputobj.read_file(group_version_control_df, "csv", "|")
    gac_table6 = inputobj.read_file(gac_h_control_plan_df, "csv", "|")
    gac_table7 = inputobj.read_file(gac_h_plan_service_employee, "csv", "|")
    gac_data = csd.gac_contract_details(gac_table1, gac_table2, gac_table3, gac_table4, gac_table5, gac_table6,
                                        gac_table7)

    print("###Reading Accumulation Of Deductions Table...###")
    deductions_path = curated_base_folder + config_dict['files']['deduction']['accumulationofdeductions_csv'] + "/year=" + parms[2] + "/month=" + parms[3] + "/day=" + parms[4]
    print("Ded Path:" + deductions_path)
    deduction_df = inputobj.read_file(deductions_path, "csv", ",")

    print("Calling member_contract details Function!!!....Join b/w ProClaim and GAC Dataset")
    pendclaim_summary_view = csd.member_contract_detials_view(gac_data, pend_member_data)

    print("Calling PendClaim Transformation...Transformation on PendClaim Dataset")
    pcd = Workflow.Computation.PendClaim_Transformation.PendClaimSummary()
    summary_df = pcd.transformation_df(pendclaim_summary_view)

    print("Calling Claim_Summary function....Action performed to join b/w Claim_Summary and AD Dataset")
    claim_deduction_df = csd.claimsummary(summary_df, deduction_df)

    print("Performing Write logic to the DataLake...")
    write_df('adl://edpdlkstrgd001.azuredatalakestore.net/CuratedZone/claimsummary', claim_deduction_df, "csv")

    print("####Job Finished Successfully...............")
    print("Job Completed at : " + str(datetime.datetime.now()))
    logger.info("Job Finished Successfully..............." +str(datetime.datetime.now()))

